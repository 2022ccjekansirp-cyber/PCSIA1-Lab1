# Hospital Database Management System

## Project Title
Hospital Database Management System for St. Elizabeth Hospital, General Santos City

## Included Features
- Dashboard
- Patient Records
- Doctors & Medical Staff
- Appointments
- Laboratory
- Pharmacy
- Billing & Payments
- Reports
- User & System Administration

## User & System Administration Forms
1. Add User — Username, Email Address, Department, Initial Password, Status Dropdown
2. Role & Access Assignment — User ID Select, Read/Write/Execute/Admin Checkboxes, Expiration Date
3. System Login — Username/Email, Password, Remember Me

## Technologies
- HTML5
- CSS3
- JavaScript
